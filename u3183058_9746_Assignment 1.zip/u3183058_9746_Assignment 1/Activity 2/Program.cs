﻿using System;

namespace Activity_2
{
    class Activity2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
